/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ecodeup.demo;

import com.ecodeup.controller.ControllerCliente;
import com.ecodeup.model.Cliente;
import com.ecodeup.vista.ViewCliente;

/**
 * @author kevin
 * Fecha: 19/11/2020
 * Asignature: Interface Design
 */
public class CrudJavaDemo {

    public static void main(String[] args) {

        ViewCliente f = new ViewCliente();
        f.setVisible(true);


    }
}
