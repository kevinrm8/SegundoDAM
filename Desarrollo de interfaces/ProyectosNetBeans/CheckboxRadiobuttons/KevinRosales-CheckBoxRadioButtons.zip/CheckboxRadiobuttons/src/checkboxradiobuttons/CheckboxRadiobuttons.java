/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkboxradiobuttons;

/**
 *
 * @author kevmar
 */
public class CheckboxRadiobuttons {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrega3 f = new Entrega3();
        f.setVisible(true);
    }

}
